import React, { useState } from 'react';
import { tablesData } from './data';

function App() {
  const [activeTab, setActiveTab] = useState(1);
  const [modalImages, setModalImages] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [statusFilter, setStatusFilter] = useState('All'); // Filter for `status_item`
  const [statusResFilter, setStatusResFilter] = useState('All'); // Filter for `status_res`
  const [branchFilter, setBranchFilter] = useState('All'); // Filter for `branch`
  const [roundFilter, setRoundFilter] = useState('Round 1'); // Filter for `round`
  

  const tabCount = 9; // Number of tabs
  const headerMapping = {
    Item: 'item',
    Status: 'status_item',
    Date: 'date',
    IP: 'lan_ip',
    Adapter: 'adapter_pos',
    Brand: 'brand',
    Os: 'os',
    Ram: 'spec_item_ram',
    Cpu: 'spec_item_cpu',
    HDD: 'spec_item_hdd',
    'SN ACC': 'sn_acc',
    RD: 'rd',
    Comment: 'comment',
    'My Image': 'myimage',
  };

  const tabName = ['POS', 'Server', 'Queue', 'Network', 'CCTVหน้าร้าน', 'CCTV Store', 'Sound'];
  const cellStyle = 'border border-gray-300 px-4 py-2';

  const openModal = (images) => {
    setModalImages(images);
    setCurrentImageIndex(0); // Start with the first image
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setModalImages([]);
    setCurrentImageIndex(0);
  };

  const showNextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % modalImages.length);
  };

  const showPrevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      (prevIndex - 1 + modalImages.length) % modalImages.length
    );
  };

  // Filter logic for Status, Duty, Branch, and Round
  const filteredRows = (rows) => {
    return rows.filter((row) => {
      const statusMatches =
        statusFilter === 'All' || row.status_item === statusFilter;
      const statusResMatches =
        statusResFilter === 'All' || row.status_res === statusResFilter;
      const branchMatches =
        branchFilter === 'All' || row.branch === branchFilter; // Filter by branch
      const roundMatches =
        roundFilter === 'All' || row.round === roundFilter; // Filter by round

      return statusMatches && statusResMatches && branchMatches && roundMatches;
    });
  };

  return (
    <div className="p-4">
      <div className="flex flex-row justify-between">
        <div>
          <h1 className="text-xl font-semibold mb-4">รายงานข้อมูล</h1>
        </div>
        <div>
          {/* Branch Filter */}
          <div>
         
          </div>




          {/* Round Filter */}
          <div >
            
          </div>
        </div>
      </div>

      {/* Status and Duty Filter */}
      <div className="mb-4">
      <label htmlFor="roundFilter" className="mr-2 font-semibold">สาขา :</label>
          <select
              id="branchFilter"
              className="border border-gray-300 px-2 py-1 rounded"
            >
              <option>AFP - ฟิวเจอร์พาร์ค รังสิต</option>
              <option>ACW - เซ็นทรัลเวิร์ด</option>
              <option>AU - MD - After You</option>
            </select>
            <label htmlFor="roundFilter" className="mr-2 font-semibold ml-5">รอบ : </label>
            <select
              id="roundFilter"
              value={roundFilter}
              onChange={(e) => setRoundFilter(e.target.value)}
              className="border border-gray-300 px-2 py-1 rounded"
            >
              <option value="All">All</option>
              <option value="Round 1">Round 1</option>
              <option value="Round 2">Round 2</option>
              {/* Add more round options as needed */}
            </select>
            <label htmlFor="roundFilter" className="mr-2 font-semibold ml-2">ปี :</label>
          <select
              id="branchFilter"
              className="border border-gray-300 px-2 py-1 rounded"
            >
              <option>2023</option>
              <option>2024</option>
              <option>2025</option>
            </select>
        <label htmlFor="statusFilter" className="mr-2 font-semibold ml-3">Filter by Status : </label>
        <select
          id="statusFilter"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="border border-gray-300 px-2 py-1 rounded"
        >
          <option value="All">All</option>
          <option value="Complete">Complete</option>
          <option value="Urgent">Urgent</option>
          <option value="Nonurgent">Nonurgent</option>
        </select>

        <label htmlFor="statusResFilter" className="mr-2 font-semibold ml-3">Filter by Duty : </label>
        <select
          id="statusResFilter"
          value={statusResFilter}
          onChange={(e) => setStatusResFilter(e.target.value)}
          className="border border-gray-300 px-2 py-1 rounded"
        >
          <option value="All">All</option>
          <option value="IT">IT</option>
          <option value="Sup">Sup</option>
        </select>
      </div>

      {/* Tabs Navigation */}
      <div role="tablist" className="tabs tabs-boxed mb-4 sticky top-0 bg-white z-20">
        {tabName.map((name, index) => (
          <a
            key={index}
            role="tab"
            className={`tab ${activeTab === index + 1 ? 'bg-gray-800 text-white text-lg' : ''} cursor-pointer`}
            onClick={() => setActiveTab(index + 1)}
          >
            {name}
          </a>
        ))}
      </div>

      {/* Tables */}
      {Array.from({ length: tabCount }).map((_, index) => (
        activeTab === index + 1 && (
          <div key={index} className="relative">
            <div className="overflow-x-auto max-h-[calc(100vh-150px)]">
              <table className="table-auto w-full border-collapse border border-gray-300">
                <thead className="bg-gray-100">
                  <tr className="text-left sticky top-0 z-20 bg-gray-100">
                    <th className={`${cellStyle} bg-gray-800`} style={{ position: 'sticky', left: 0, zIndex: 10 }}>#</th>
                    {Object.keys(headerMapping).map((header, index) => (
                      <th key={index} className={`${cellStyle} bg-gray-800`}>{header}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="overflow-y-auto bg-white">
                  {filteredRows(tablesData[index]).map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      <td className={`${cellStyle} bg-gray-600`} style={{ position: 'sticky', left: 0 }}>
                        {rowIndex + 1}
                      </td>
                      {Object.values(headerMapping).map((key, colIndex) => (
                        <td
                          key={colIndex}
                          className={`${cellStyle} ${key === 'status_item'
                            ? row.status_item === 'Complete'
                              ? 'bg-green-200'
                              : row.status_item === 'Urgent'
                                ? 'bg-red-200'
                                : row.status_item === 'Nonurgent'
                                  ? 'bg-yellow-200'
                                  : ''
                            : ''
                            }`}
                        >
                          {key === 'status_item' ? (
                            <div>
                              <div>{row.status_item}</div>
                              {row.status_res && (
                                <div className="text-gray-500 text-sm mt-1">
                                  ({row.status_res})
                                </div>
                              )}
                            </div>
                          ) : key === 'date' ? (
                            <div>{row.date}</div>
                          ) : key === 'myimage' ? (
                            <button
                              className="btn btn-md btn-primary text-xs"
                              onClick={() => openModal(row.myimage)}
                            >
                              View Images
                            </button>
                          ) : (
                            row[key]
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ))}

      {/* Modal for Images */}
      {isModalOpen && (
  <div className="fixed inset-0 bg-gray-800 bg-opacity-90 flex items-center justify-center z-50">
    <button
        className="absolute top-4 right-4 text-red-500 font-bold text-3xl"
        onClick={closeModal}
      >
        &times;
      </button>
    <div className="relative max-w-3xl w-full bg-white rounded shadow-lg">
      
      <div className="p-4">
        {/* Display Grid of Images */}
        <div className="grid grid-cols-3 gap-4">
          {modalImages.map((image, index) => (
            <div
              key={index}
              className="cursor-pointer"
              onClick={() => {
                setCurrentImageIndex(index);
              }}
            >
              <img
                src={image}
                alt={`Image ${index + 1}`}
                className="w-full h-full object-cover rounded"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
)}


    </div>
  );
}

export default App;
